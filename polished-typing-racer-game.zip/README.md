# VELOCITYPE

**A neon-outrun typing racer for the browser.** Words speed down the highway toward your hover-racer — lock on with the first matching letter, vaporize the word before it crosses the impact line, chain combos, charge nitro, and outrun your own record.

![genre](https://img.shields.io/badge/genre-typing%20racer-3df5ff)
![stack](https://img.shields.io/badge/stack-React%2019%20%2B%20Vite%20%2B%20Tailwind%204-ff3df0)
![deps](https://img.shields.io/badge/audio%20%2F%20gfx-zero%20assets-ffb54d)

## Play

| Input | Action |
| --- | --- |
| `A–Z` | Lock a word / fire a letter |
| `SPACE` | Ignite nitro (when the bar is full) |
| `ESC` | Pause / resume |
| `R` | Instant restart (game over / pause) |
| `M` | Toggle sound (menus) |

On touch devices the native keyboard drives typing (via a hidden input), with on-screen **nitro** and **pause** buttons. The playfield resizes itself above the soft keyboard.

## Features

- Juicy feedback: trauma-based screen shake, per-keystroke lasers, particle bursts, shockwaves, floating score popups, red/cyan flashes, slow-mo wreck sequence
- Combo multiplier (up to x4), nitro boost with triple score, 3 hull charges, boss "TURBO" words worth triple
- Difficulty ramp over ~150 s + milestone toasts
- Start screen, countdown, pause, game-over with instant restart
- Local high-score table (top 8, `localStorage`, seeded rivals, arcade name entry)
- Live WPM window, accuracy, max-chain stats
- Synthesized WebAudio SFX + adaptive engine hum — no audio files
- Canvas renderer with baked offscreen layers (sky / track / vignette + scanlines) and adaptive resolution tiers to hold 60 fps on desktop and mobile

## Tech

- **React 19 + TypeScript + Vite**, **Tailwind CSS 4** for UI chrome
- Zero-dependency game core: framework-free engine (`src/game/engine.ts`), hand-rolled canvas renderer (`src/game/renderer.ts`), synth SFX (`src/game/audio.ts`)
- `lucide-react` icons; fonts: Orbitron, Rajdhani, JetBrains Mono

## Develop

```bash
npm install
npm run dev      # local dev
npm run build    # single-file production build → dist/index.html
npm run preview  # preview the production build
```

The production build inlines everything into one HTML file, ready to drop onto GitHub Pages, Netlify, Vercel, or any static host.
